<?php

declare(strict_types=1);

namespace App\Models;

final class Pick extends Model
{
}
